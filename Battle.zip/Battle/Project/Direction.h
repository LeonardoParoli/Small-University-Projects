//
// Created by Leonardo on 6/26/2017.
//

#ifndef COLDSPACE_DIRECTIONS_H
#define COLDSPACE_DIRECTIONS_H

enum class Direction {Up=0,Left, Down, Right};

#endif //COLDSPACE_DIRECTIONS_H
