Paroli Leonardo
Matricola 6105769
Corso di Ingegneria Informatica - I� anno
Esame di Fondamenti di Informatica/Programmazione	
