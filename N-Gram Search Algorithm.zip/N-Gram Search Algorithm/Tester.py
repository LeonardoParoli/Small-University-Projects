from Word_Database import Word_Database
from timeit import default_timer as timer
import plotly
from plotly import figure_factory as ff
import pickle
from random import randint


def Tester(init, n_tests, n_grams, file):
    # opening word database
    start = timer()
    data = open(file, "r")
    data = data.readlines()
    database = Word_Database(data)
    end = timer()
    initialization_time = end - start
    if init:
        # Processing database to grams
        start = timer()
        database.processDatabaseToNGrams(n_grams)
        end = timer()
        process_time = end - start
        print(round(process_time, 2))

    else:
        try:
            database.getNGrams().NGram_dict = pickle.load(open("Saved_Grams\Gram_Dict_" + str(n_grams) + ".p", "rb"))
            database.getNGrams().Word_dict = pickle.load(open("Saved_Grams\Word_Dict_" + str(n_grams) + ".p", "rb"))
            database.getNGrams().Short_grams = pickle.load(open("Saved_Grams\Short_Grams_" + str(n_grams) + ".p", "rb"))
            database.getNGrams().Gram_index = n_grams
        except (OSError, IOError):
            print("Couldn't load file, check available N_grams. Shutting down...")
            return

    time_table_data = [['Word', 'Edit Distance Search Time', 'N-Gram Search Time']]
    nearestWords_data =[['Word','Edit Distance Search', 'N-Gram Search']]
    i = 0
    while i < n_tests:
        word = database.getWord(randint(0, database.getSize()))
        print('Testing word: ' + word + ' ...')

        # bruteforce query search
        start = timer()
        nearToQuery=database.nearToQuery('sottocutaneo')
        end = timer()

        print(nearToQuery[0])
        print(nearToQuery[1])

        bruteforce_search_time = end - start

        # gram optimized query search
        start = timer()
        nearToQueryWithGrams=database.nearToQueryWithGrams('sottocutaneo', 0.6)
        end = timer()

        print(nearToQueryWithGrams[0])
        print(nearToQueryWithGrams[1])

        gram_search_time = end - start

        print(round(bruteforce_search_time, 3))
        print(round(gram_search_time, 3))

        #Appending new data to tables
        new_data = [word, round(bruteforce_search_time, 3), round(gram_search_time, 3)]
        time_table_data.append(new_data)
        nearest_data=[word, len(nearToQuery[1])-1,len(nearToQueryWithGrams[1])-1]
        nearestWords_data.append(nearest_data)

        del nearToQuery
        del nearToQueryWithGrams

        i = i + 1

    # Building tables
    average = ['AVERAGE:', 0, 0]
    for i in range(1,int(len(time_table_data))):
        average[1] = average[1] + (time_table_data[i])[1]
        average[2] = average[2] + (time_table_data[i])[2]
    average[1] = round((average[1] / n_tests), 3)
    average[2] = round((average[2] / n_tests), 3)
    time_table_data.append(average)

    average = ['AVERAGE:', 0, 0]
    for i in range(1,int(len(nearestWords_data))):
        average[1] = average[1] + (nearestWords_data[i])[1]
        average[2] = average[2] + (nearestWords_data[i])[2]
    average[1] = round((average[1] / n_tests), 3)
    average[2] = round((average[2] / n_tests), 3)
    nearestWords_data.append(average)

    time_table = ff.create_table(time_table_data)
    plotly.offline.plot(time_table, filename="Tester_Time_Table.html")

    nearestWords_table = ff.create_table(nearestWords_data)
    plotly.offline.plot(nearestWords_table, filename="Tester_WordsFound_Table.html")

Tester(True, 1, 3, "Word_Data_280000.txt")
