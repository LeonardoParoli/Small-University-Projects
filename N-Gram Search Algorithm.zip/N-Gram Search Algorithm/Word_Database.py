from NGrams import NGrams
import numpy as np
import pickle
import math


class Operations:
    def __init__(self):
        self.DELETE = 1
        self.INSERT = 2
        self.COPY = 3
        self.TWIDDLE = 4
        self.REPLACE = 5
        self.Delete_Cost = 1
        self.Insert_Cost = 1
        self.Copy_Cost = 0
        self.Twiddle_Cost = 2
        self.Replace_Cost = 2
        self.Sentinel = 400

    def setDeleteCost(self, cost):
        self.Delete_Cost = cost

    def setInsertCost(self, cost):
        self.Insert_Cost = cost

    def setCopyCost(self, cost):
        self.Copy_Cost = cost

    def setTwiddleCost(self, cost):
        self.Twiddle_Cost = cost

    def setReplaceCost(self, cost):
        self.Replace_Cost = cost


class Word_Database:
    def __init__(self, data):
        self.longestWordSize = 0
        self.wordbase = data
        for i in range(len(self.wordbase)):
            self.wordbase[i] = self.wordbase[i].strip('\n')
            self.wordbase[i] = self.wordbase[i].strip('\t')
            if self.longestWordSize > len(self.wordbase[i]):
                self.longestWordSize = len(self.wordbase[i])
        self.nWords = len(self.wordbase)
        self.NGrams = NGrams()
        self.operations = Operations()

    def getDatabase(self):
        return self.wordbase
    def getWord(self, id):
        return self.wordbase[id]
    def getSize(self):
        return self.nWords
    def getNGrams(self):
        return self.NGrams

    def editDistance(self, x, y):
        m = len(x)
        n = len(y)

        C = np.zeros([m + 1, n + 1])
        Op = np.zeros([m + 1, n + 1])

        for i in range(m + 1):
            C[i, 0] = i * self.operations.Delete_Cost
            Op[i, 0] = self.operations.DELETE
        for j in range(n + 1):
            C[0, j] = j * self.operations.Insert_Cost
            Op[0, j] = self.operations.INSERT

        i_index = [int(h) + 1 for h in range(m)]
        j_index = [int(w) + 1 for w in range(n)]
        for i in i_index:
            for j in j_index:

                # 200 is the maximum number of letters of any word in any language.
                # Sentinel's value is 400.

                C[i, j] = self.operations.Sentinel
                if x[i - 1] == y[j - 1]:
                    C[i, j] = C[i - 1, j - 1] + self.operations.Copy_Cost
                    Op[i, j] = self.operations.COPY
                if (x[i - 1] != y[j - 1]) and (C[i - 1, j - 1] + self.operations.Replace_Cost < C[i, j]):
                    C[i, j] = C[i - 1, j - 1] + self.operations.Replace_Cost
                    Op[i, j] = self.operations.REPLACE
                if i > 2 and j > 2 and x[i - 1] == y[j - 2] and x[i - 2] == y[j - 1] and (
                        C[i - 2, j - 2] + self.operations.Twiddle_Cost < C[i, j]):
                    C[i, j] = C[i - 2, j - 2] + self.operations.Twiddle_Cost
                    Op[i, j] = self.operations.TWIDDLE
                if (C[i - 1, j] + self.operations.Delete_Cost < C[i, j]):
                    C[i, j] = C[i - 1, j] + self.operations.Delete_Cost
                    Op[i, j] = self.operations.DELETE
                if (C[i, j - 1] + self.operations.Insert_Cost < C[i, j]):
                    C[i, j] = C[i, j - 1] + self.operations.Insert_Cost
                    Op[i, j] = self.operations.INSERT

        results = [C, Op, C[m, n]]
        return results

    def addNgrams(self, N_grams, short_grams):
        self.NGrams.NGram_dict = N_grams
        self.NGrams.Short_grams = short_grams

    def findKey(self,Gram_bet, key):
        keys = Gram_bet.keys()
        found = False
        for i in keys:
            if i == key:
                found = True
        return found

    def processDatabaseToNGrams(self, gram_index):

        self.NGrams.NGram_dict = {}  # dictionary
        self.NGrams.Short_grams = []  # array
        self.NGrams.Gram_index=gram_index

        iteration = 0
        # processing database
        for i in self.wordbase:
            word_length = len(i)
            iteration += 1
            # Gram index too high
            if word_length < gram_index:
                self.NGrams.Short_grams.append(i)
            # Gram index has correct size
            else:
                # dissecting word from database
                j = 0
                grams = []
                newGram = ''
                while j + gram_index - 1 < word_length:
                    for k in range(gram_index):
                        newGram = newGram + i[j + k]
                    grams.append(newGram)
                    j = j + 1
                    newGram = ''
                # adding gram to gram_dict if not found, append word in any case.
                for h in grams:
                    if self.findKey(self.NGrams.NGram_dict, h):
                        newList = self.NGrams.NGram_dict.get(h)
                        newList.append(i)
                        self.NGrams.NGram_dict[h] = newList
                    else:
                        if len(self.NGrams.NGram_dict) == 0:
                            newList = []
                            newList.append(i)
                            self.NGrams.NGram_dict = {h: newList}
                        else:
                            newList = []
                            newList.append(i)
                            self.NGrams.NGram_dict[h] = newList
                if len(self.NGrams.Word_dict)==0:
                    self.NGrams.Word_dict={i : grams}
                else:
                    self.NGrams.Word_dict[i] = grams

        pickle.dump(self.NGrams.NGram_dict, open("Saved_Grams\Gram_Dict_" + str(gram_index) + ".p", "wb"))
        pickle.dump(self.NGrams.Short_grams, open("Saved_Grams\Short_Grams_" + str(gram_index) + ".p", "wb"))
        pickle.dump(self.NGrams.Word_dict, open("Saved_Grams\Word_Dict_" + str(gram_index) + ".p", "wb"))

    def maxDistance(self,query):
        return int(0.6 * (math.pow(len(query), 0.7))) + 1

    # bruteforce query search
    def nearToQuery(self, query):

        difference_limit = self.maxDistance(query)
        nearestWord = ['', self.operations.Sentinel]
        bestWords = {}
        for i in self.wordbase:
            score = int(self.editDistance(query, i)[2])
            if score <= difference_limit:
                current_word = [i, score]
                if score < nearestWord[1]:
                    bestWords[nearestWord[0]]=nearestWord[1]
                    nearestWord = [i, score]
                bestWords[i]=score
        return [nearestWord, bestWords]


    # Gram_optimized query search
    def nearToQueryWithGrams(self, query, jaccard):

        #checking if the query is too short for current gram index
        if len(query) < self.NGrams.Gram_index:
            difference_limit = self.maxDistance(query)
            nearestWord = ['', self.operations.Sentinel]
            bestWords = {}
            for i in self.NGrams.Short_grams:
                score = int(self.editDistance(query, i)[2])
                if score <= difference_limit:
                    if score < nearestWord[1]:
                        bestWords[nearestWord[0]]=nearestWord[1]
                        nearestWord = [i, score]
                    else:
                        bestWords[i]=score
            return [nearestWord, [bestWords]]

        else:
            # dissecting query into grams
            i = 0
            grams = []
            newGram = ''
            while i + self.NGrams.Gram_index - 1 < len(query):
                for j in range(self.NGrams.Gram_index):
                    newGram = newGram + query[i + j]
                grams.append(newGram)
                i = i + 1
                newGram = ''

            # search for words
            words_found=[]
            nearestWord=['', 0]
            bestWords={}
            for g in grams:
                if self.findKey(self.NGrams.NGram_dict,g):
                    words_found= words_found + self.NGrams.NGram_dict[g]
            for w in words_found:
                word_grams=self.NGrams.Word_dict[w]
                intersect_grams=0
                union_grams= len(grams) + len(word_grams)
                for wg in word_grams:
                    for g in grams:
                        if wg==g:
                            union_grams = union_grams - 1
                            intersect_grams= intersect_grams + 1
                current_jaccard=round((intersect_grams/union_grams),3)
                if current_jaccard > jaccard:
                    if current_jaccard > nearestWord[1]:
                        bestWords[nearestWord[0]]=nearestWord[1]
                        nearestWord= [w,current_jaccard]
                    else:
                        bestWords[w]=current_jaccard
            return [nearestWord, bestWords]
