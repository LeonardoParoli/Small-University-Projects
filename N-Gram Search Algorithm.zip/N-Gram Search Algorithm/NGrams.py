
class NGrams:
    def __init__(self):
        self.NGram_dict={}
        self.Word_dict={}
        self.Short_grams=[]
        self.Gram_index=0