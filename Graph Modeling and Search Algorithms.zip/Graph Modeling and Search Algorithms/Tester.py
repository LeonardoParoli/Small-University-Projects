from Graph import Graph
from timeit import default_timer as timer
import numpy as np
import plotly
from plotly import figure_factory as ff
import pickle
import matplotlib.pyplot as plt


def Size_Tester(max_n_nodes, arc_probability, finesse):
    n_elements = int(max_n_nodes / finesse) + 1

    Building_Time = np.zeros(n_elements)
    CC_Time = np.zeros(n_elements)
    MST_Time = np.zeros(n_elements)
    X = np.arange(0, max_n_nodes + 1, finesse)
    table_data = [['Size', 'Building time', 'Connected Components Time', 'MST-Kruscal Time']]

    # size-increasing test
    iteration = 0
    index = 0
    keys = []
    while iteration <= max_n_nodes:
        print('Testing on size:' + str(iteration) + ' ...')

        start = timer()
        graph = Graph(iteration, keys, True, False)
        graph.randomizeGraph(arc_probability)
        end = timer()
        building_time = round(end - start, 4)

        start = timer()
        graph.MST_Kruskal()
        end = timer()
        mst_time = round(end - start, 4)

        graph = Graph(iteration, keys, True, True)
        graph.randomizeGraph(arc_probability)

        start = timer()
        graph.connected_Components()
        end = timer()
        cc_time = round(end - start, 4)

        Building_Time[index] = building_time
        CC_Time[index] = cc_time
        MST_Time[index] = mst_time
        new_data = [X[index], building_time, cc_time, mst_time]
        table_data.append(new_data)

        index = index + 1
        iteration = iteration + finesse
        keys = [str(i) for i in range(iteration)]
    print('Finished!')

    # making a  graph
    pickle.dump(Building_Time, open('Results/Size_Building_Time.p', "wb"))
    pickle.dump(CC_Time, open('Results/Size_CC_Time.p', "wb"))
    pickle.dump(MST_Time, open('Results/Size_MST_Time.p', "wb"))

    plt.plot(X, Building_Time)
    plt.plot(X, CC_Time)
    plt.plot(X, MST_Time)
    plt.legend(['Graph Building Time', 'Connected Components Time', 'MST-Kruscal Time'])
    plt.xlabel('Size')
    plt.ylabel('Time in seconds')
    plt.title('Size-Increasing Test')
    plt.show()

    # making a table
    time_table = ff.create_table(table_data)
    plotly.offline.plot(time_table, filename="Size_Time_Table.html")


def Probability_Tester(n_nodes, finesse):
    n_elements = int(100 / finesse) + 1

    Building_Time = np.zeros(n_elements)
    CC_Time = np.zeros(n_elements)
    MST_Time = np.zeros(n_elements)
    X = np.arange(0, 100 + 1, finesse)
    table_data = [['Arc Probability', 'Building time', 'Connected Components Time', 'MST-Kruscal Time']]

    # Probability-increasing test
    iteration = 0
    index = 0
    keys = [str(i) for i in range(n_nodes)]
    while iteration <= 100:
        print('Testing on Probability:' + str(iteration) + '% ...')
        start = timer()
        graph = Graph(n_nodes, keys, True, False)
        graph.randomizeGraph(iteration)
        end = timer()
        building_time = round(end - start, 4)

        start = timer()
        graph.MST_Kruskal()
        end = timer()
        mst_time = round(end - start, 4)

        graph = Graph(n_nodes, keys, True, True)
        graph.randomizeGraph(iteration)
        start = timer()
        graph.connected_Components()
        end = timer()
        cc_time = round(end - start, 4)

        Building_Time[index] = building_time
        CC_Time[index] = cc_time
        MST_Time[index] = mst_time
        new_data = [X[index], building_time, cc_time, mst_time]
        table_data.append(new_data)

        index = index + 1
        iteration = iteration + finesse
    print('Finished!')

    # making a  graph
    pickle.dump(Building_Time, open('Results/Probability_Building_Time.p', "wb"))
    pickle.dump(CC_Time, open('Results/Probability_CC_Time.p', "wb"))
    pickle.dump(MST_Time, open('Results/Probability_MST_Time.p', "wb"))

    plt.plot(X, Building_Time)
    plt.plot(X, CC_Time)
    plt.plot(X, MST_Time)
    plt.legend(['Graph Building Time', 'Connected Components Time', 'MST-Kruscal Time'])
    plt.xlabel('Size')
    plt.ylabel('Time in seconds')
    plt.title('Probability-Increasing Test')
    plt.show()

    # making a table
    time_table = ff.create_table(table_data)
    plotly.offline.plot(time_table, filename="Probability_Time_Table.html")


def ProbabilityAndSize_Tester(max_n_nodes, finesse):
    n_elements = int(max_n_nodes / finesse) + 1
    probability_finesse = int(100 / (max_n_nodes / finesse))

    Building_Time = np.zeros(n_elements)
    CC_Time = np.zeros(n_elements)
    MST_Time = np.zeros(n_elements)
    X = np.arange(0, max_n_nodes + 1, finesse)
    table_data = [['Size', 'Probability', 'Building time', 'Connected Components Time', 'MST-Kruscal Time']]

    # Probability scales with size, up to maximun size
    arc_probability = 0
    index = 0
    iteration = 0
    keys = []
    while iteration <= max_n_nodes:
        print('Testing on size:' + str(iteration) + ' and on probability:' + str(arc_probability) + '% ...')

        start = timer()
        graph = Graph(iteration, keys, True, False)
        graph.randomizeGraph(arc_probability)
        end = timer()
        building_time = round(end - start, 4)

        start = timer()
        graph.MST_Kruskal()
        end = timer()
        mst_time = round(end - start, 4)

        graph = Graph(iteration, keys, True, True)
        graph.randomizeGraph(arc_probability)
        start = timer()
        graph.connected_Components()
        end = timer()
        cc_time = round(end - start, 4)

        Building_Time[index] = building_time
        CC_Time[index] = cc_time
        MST_Time[index] = mst_time
        new_data = [X[index], arc_probability, building_time, cc_time, mst_time]
        table_data.append(new_data)

        index = index + 1
        iteration = iteration + finesse
        arc_probability = arc_probability + probability_finesse
        keys = [str(i) for i in range(iteration)]
    print('Finished!')

    # making a  graph
    pickle.dump(Building_Time, open('Results/Probability_Size_Building_Time.p', "wb"))
    pickle.dump(CC_Time, open('Results/Probability_Size_CC_Time.p', "wb"))
    pickle.dump(MST_Time, open('Results/Probability_Size_MST_Time.p', "wb"))

    plt.plot(X, Building_Time)
    plt.plot(X, CC_Time)
    plt.plot(X, MST_Time)
    plt.legend(['Graph Building Time', 'Connected Components Time', 'MST-Kruscal Time'])
    plt.xlabel('Size')
    plt.ylabel('Time in seconds')
    plt.title('Size and Probability-Increasing Test')
    plt.show()

    # making a table
    time_table = ff.create_table(table_data)
    plotly.offline.plot(time_table, filename="Size&Probability_Time_Table.html")


Size_Tester(1000, 10, 50)
Probability_Tester(100, 5)
ProbabilityAndSize_Tester(1000, 50)

# test_examples:
keys_10 = [str(i) for i in range(10)]
keys_25 = [str(i) for i in range(25)]
keys_50 = [str(i) for i in range(50)]
keys_100 = [str(i) for i in range(100)]

# an example of size-increasing test
arc_probability = 2
n_nodes = 10
graph = Graph(n_nodes, keys_10, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

n_nodes = 25
graph = Graph(n_nodes, keys_25, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

n_nodes = 50
graph = Graph(n_nodes, keys_50, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

n_nodes = 100
graph = Graph(n_nodes, keys_100, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

# an example of arc-probability-increasing test
n_nodes = 25
arc_probability = 1
graph = Graph(n_nodes, keys_25, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

arc_probability = 2
graph = Graph(n_nodes, keys_25, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

arc_probability = 10
graph = Graph(n_nodes, keys_25, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

arc_probability = 50
graph = Graph(n_nodes, keys_25, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

# an example of test where both are increasing
n_nodes = 10
arc_probability = 1
graph = Graph(n_nodes, keys_10, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

n_nodes = 25
arc_probability = 2
graph = Graph(n_nodes, keys_25, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

n_nodes = 50
arc_probability = 10
graph = Graph(n_nodes, keys_50, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

n_nodes = 100
arc_probability = 50
graph = Graph(n_nodes, keys_100, True, False)
graph.randomizeGraph(arc_probability)
print('Plotting graph with size ' + str(n_nodes) + ' and  probability of ' + str(arc_probability))
graph.plotGraph()
arcs = graph.MST_Kruskal()
graph.plotGraphWithArcs(arcs)

# example of connected components

keys = [str(i) for i in range(20)]
graph = Graph(20, keys, True, True)
graph.randomizeGraph(1)
graph.plotGraph()
graph.plotConnectedComponents()
