class Node:
    def __init__(self, id):
        self.id = id

