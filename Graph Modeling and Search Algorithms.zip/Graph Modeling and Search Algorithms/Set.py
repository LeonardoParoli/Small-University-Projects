from Element import Element

class Set:
    def __init__(self):
        self.first=None
        self.tail=None
        self.size=0

    def getSize(self):
        return self.size

    def updateSize(self,size):
        self.size=size

    def find(self, element):
        found=False
        i=self.first
        while i is not None and not found:
            if(i.element==element):
                found=True
            else:
                i=i.next
        return found

    def add(self, element):
        newElement=Element(self,element)
        if self.first is None:
            self.first=newElement
        else:
            self.tail.setNext(newElement)
        self.tail=newElement
        self.size=self.size +1

    def moveElement(self,element):
        if self.first is None:
            self.first=element
        self.tail.setNext(element)
        self.tail=element
        element.setHead(self)

    def printSet(self):
        current_element = self.first
        print('{ ')
        while current_element is not None:
            print(current_element.getElement() + ', ')
            current_element=current_element.getNext()
        print(' }')

    def intoList(self):
        list=[]
        i=self.first
        while i is not None:
            list.append(i.element)
            i=i.getNext()
        return list