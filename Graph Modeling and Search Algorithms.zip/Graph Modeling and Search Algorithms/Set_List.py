from Set import Set

class Set_List:
    def __init__(self):
        self.sets=[]

    def getSets(self):
        return self.sets

    def makeSet(self, element):
        set=Set()
        set.add(element)
        self.sets.append(set)

    def findSet(self, element):
        for i in range(len(self.sets)):
            if self.sets[i].find(element):
                return [True, i]
        return [False, None]

    def union(self, x, y):
        check_x= self.findSet(x)
        check_y= self.findSet(y)
        if check_x[0] and check_y[0] and self.sets[check_x[1]] != self.sets[check_y[1]]:
            size_x= self.sets[check_x[1]].getSize()
            size_y= self.sets[check_x[1]].getSize()
            if(size_x > size_y):
                i=self.sets[check_y[1]].first
                while i is not None:
                    self.sets[check_x[1]].moveElement(i)
                    i=i.next
                self.sets[check_x[1]].updateSize(size_x+size_y)
                del self.sets[check_y[1]]
            else:
                i=self.sets[check_x[1]].first
                while i is not None:
                    self.sets[check_y[1]].moveElement(i)
                    i=i.next
                self.sets[check_y[1]].updateSize(size_x + size_y)
                del self.sets[check_x[1]]

    def printSets(self):
        for i in self.sets:
            i.printSet()




