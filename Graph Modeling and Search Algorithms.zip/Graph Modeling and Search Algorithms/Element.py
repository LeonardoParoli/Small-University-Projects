
class Element:
    def __init__(self,head,element ):
        self.element=element
        self.next=None
        self.head=head

    def getElement(self):
        return self.element

    def gethead(self):
        return self.head

    def getNext(self):
        return self.next

    def setNext(self,next):
        self.next=next

    def setHead(self,head):
        self.head=head