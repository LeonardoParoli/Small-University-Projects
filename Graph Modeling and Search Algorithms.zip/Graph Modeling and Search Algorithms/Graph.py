import numpy as np
from Node import Node
import random
from random import randint
from Set_List import Set_List
import networkx as nx
import matplotlib.pyplot as plt

class Graph:
    def __init__(self, n_nodes, keys, isWeighted, enable_isolated_nodes):
        self.nodes=[]
        self.adjMatrix= np.zeros([n_nodes, n_nodes])
        for i in keys:
            node=Node(i)
            self.nodes.append(node)

        self.isWeighted=isWeighted
        self.enable_isolated_nodes=enable_isolated_nodes

    def IsWeighted(self):
        return self.isWeighted

    def getNodes(self):
        return self.nodes

    def getArcs(self):
        rows = self.adjMatrix.shape[0]
        columns = self.adjMatrix.shape[1]
        arcs=[]
        for i in range(rows):
            for j in range(columns):
                if self.adjMatrix[i,j]>= 1:
                    w=self.adjMatrix[i,j]
                    newArc=[self.nodes[i].id,self.nodes[j].id, w]
                    arcs.append(newArc)
        return arcs

    def findNode(self, key):
        found= False
        position=None
        for i in range(len(self.nodes)):
            if(self.nodes[i].id == key):
                found=True
                position=i
        return [found, position]

    def randomizeGraph(self, arc_probability):
        def throwProbability():
            return int(random.random()*100)

        rows = self.adjMatrix.shape[0]
        columns = self.adjMatrix.shape[1]
        if self.isWeighted:
            for i in range(rows):
                for j in range(columns):
                    if throwProbability() <= arc_probability:
                        self.adjMatrix[i,j] = throwProbability()
            if not self.enable_isolated_nodes:
                for k in range(rows):
                    if np.count_nonzero(self.adjMatrix[k])== 0:
                        self.adjMatrix[k,randint(0, (self.adjMatrix.shape[1]-1))]= throwProbability()

        else:
            for i in range(rows):
                for j in range(columns):
                    if throwProbability() <= arc_probability:
                        self.adjMatrix[i, j] = 1
            if not self.enable_isolated_nodes:
                for k in range(rows):
                    if np.count_nonzero(self.adjMatrix[k])== 0:
                        self.adjMatrix[k,randint(0, (self.adjMatrix.shape[1]-1))]= 1

    def printNodes(self):
        print('[ ', end='')
        for i in self.nodes:
            print(str(i.id) + ', ', end='')
        print(']')

    def printArcs_Node(self, key):
        columns = self.adjMatrix.shape[1]
        check = self.findNode(key)
        if check[0]:
            print(self.nodes[check[1]].id +' connected to [ ', end='')
            for j in range(columns):
                if self.adjMatrix[check[1],j] >= 1:
                    print(self.nodes[check[1]].id +'{w: '+ self.adjMatrix[check[1],j] + '}, ')
        print(']')
    def getArcs_Node(self,key):
        columns = self.adjMatrix.shape[1]
        check = self.findNode(key)
        if check[0]:
            print(self.nodes[check[1]].id + ' connected to [ ', end='')
            for j in range(columns):
                if self.adjMatrix[check[1], j] >= 1:
                    print(self.nodes[check[1]].id + '{w: ' + self.adjMatrix[check[1], j] + '}, ')
        print(']')

    def connected_Components(self):
        set_list = Set_List()
        arcs = self.getArcs()

        for i in self.nodes:
            set_list.makeSet(i.id)
        for j in arcs:
            if set_list.findSet(j[0])[1] != set_list.findSet(j[1])[1]:
                set_list.union(j[0], j[1])
        return set_list.getSets()

    def MST_Kruskal(self):

        def modified_mergeSort(array):
            if len(array) > 1:
                mid = int(len(array) / 2)
                right = array[:mid]
                left = array[mid:]
                modified_mergeSort(right)
                modified_mergeSort(left)
                modified_merge(array, right, left)

        def modified_merge(array, left, right):
            i = 0
            j = 0
            k = 0
            while i < len(left) and j < len(right):
                if left[i][2] < right[j][2]: #modified to handle arcs' weight
                    array[k] = left[i]
                    i = i + 1
                else:
                    array[k] = right[j]
                    j = j + 1
                k = k + 1
            while i < len(left):
                array[k] = left[i]
                i = i + 1
                k = k + 1

            while j < len(right):
                array[k] = right[j]
                j = j + 1
                k = k + 1

        set_list=Set_List()
        arcs=self.getArcs()

        A = []
        for i in self.nodes:
            set_list.makeSet(i.id)
        modified_mergeSort(arcs)
        iteration=0
        for j in arcs:
            if iteration > int(len(self.nodes)-1):
                return A
            if set_list.findSet(j[0])[1] != set_list.findSet(j[1])[1]:
                A.append(j)
                set_list.union(j[0],j[1])
                iteration=iteration + 1
        if iteration <int(len(self.nodes) -1):
            print('Careful! MST-Kruscal revealed this graph to be unconnected')
        return A

    def plotGraph(self):
        G = nx.Graph()

        nodes=[self.nodes[i].id for i in range(len(self.nodes))]
        G.add_nodes_from(nodes)

        weighted_arcs=self.getArcs()
        for i in weighted_arcs:
            G.add_edge(i[0],i[1], weight= i[2])

        pos = nx.spring_layout(G)
        nx.draw(G, pos=pos, with_labels=True, node_color='g', node_size=100, font_size=8  )
        plt.show()

    def plotGraphWithArcs(self, arcs):
        G = nx.Graph()

        nodes = [self.nodes[i].id for i in range(len(self.nodes))]
        G.add_nodes_from(nodes)

        weighted_arcs = arcs
        for i in weighted_arcs:
            G.add_edge(i[0], i[1], weight=i[2])

        pos = nx.spring_layout(G)
        nx.draw(G, pos=pos, with_labels=True, node_color='g', node_size=100, font_size=8)
        plt.show()

    def plotConnectedComponents(self):
        G=nx.Graph()
        G.add_nodes_from([self.nodes[i].id for i in range(len(self.nodes))])
        pos = nx.shell_layout(G)
        weighted_arcs = self.getArcs()
        for i in weighted_arcs:
            G.add_edge(i[0], i[1], weight=i[2])

        cycle=0
        sets= self.connected_Components()
        for i in sets:
            nodes=i.intoList()
            cycle=[random.random()]* int(len(nodes))
            nx.draw_networkx_nodes(G,pos=pos, nodelist=nodes ,node_color=cycle,  vmin=0.0,vmax=1.0, node_size=100)
        nx.draw_networkx_edges(G, pos=pos)
        nx.draw_networkx_labels(G,pos=pos, font_size=8)
        plt.show()